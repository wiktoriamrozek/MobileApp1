const express = require('express');
const app = express();
const port = 3000;

const cors = require('cors');
app.use(cors());

// Nowe trasy z punktu A do punktu B
const routes = [
  { 
    id: 1, 
    name: 'UBB Bielsko Biała - Gemini Bielsko Biała', 
    waypoints: [
      { lat: 49.78331330017874, lng: 19.058413714127763, description: 'UBB Bielsko Biała (Start)' },
      { lat: 49.802858214334584, lng: 19.051228206722694, description: 'Gemini Bielsko Biała (Cel)' }
    ]
  },
  { 
    id: 2, 
    name: 'UBB Bielsko Biała - Cygański Las Bielsko Biała', 
    waypoints: [
      { lat: 49.78331330017874, lng: 19.058413714127763, description: 'UBB Bielsko Biała (Start)' },
      { lat: 49.78453444322205, lng: 19.042648316511066, description: 'Cygański Las Bielsko Biała (Cel)' }
    ]
  },
  { 
    id: 3, 
    name: 'UBB Bielsko Biała - Sfera Bielsko Biała', 
    waypoints: [
      { lat: 49.78331330017874, lng: 19.058413714127763, description: 'UBB Bielsko Biała (Start)' },
      { lat: 49.82737566676933, lng: 19.049874676036342, description: 'Sfera Bielsko Biała (Cel)' }
    ]
  }
];

app.get('/', (req, res) => {
  res.send('<h1>Welcome to the Routes API</h1><p>Use /routes to get the list of routes.</p>');
});

app.get('/routes', (req, res) => {
  console.log('GET /routes');
  res.json(routes.map(route => ({ id: route.id, name: route.name })));
});

app.get('/routes/:id', (req, res) => {
  const route = routes.find(r => r.id == req.params.id);
  console.log(`GET /routes/${req.params.id}`);
  if (route) {
    res.json(route);
  } else {
    res.status(404).send('Route not found');
  }
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
