let map; // Tworzymy zmienną globalną do przechowywania mapy
let routeControl; // Zmienna do kontrolowania trasy
let routeMarkers = []; // Tablica do przechowywania markerów
let movingMarker; // Zmienna do przechowywania poruszającej się kropki
let currentWaypointIndex = 0; // Indeks bieżącego punktu trasy
let routeWaypoints = []; // Tablica współrzędnych trasy

document.addEventListener('DOMContentLoaded', onPageLoaded, false);

// Inicjalizacja mapy tylko raz
function onPageLoaded() {
    map = L.map('map').setView([51.505, -0.09], 13);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);

    fetchRoutes(); // Ładowanie tras po załadowaniu aplikacji
}

// Ładowanie dostępnych tras
function fetchRoutes() {
    console.log('Fetching routes...');
    fetch('http://127.0.0.1:3000/routes')  // Zmiana localhost na 127.0.0.1
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Received data:', data);
            const select = document.getElementById('routeSelect');
            select.innerHTML = ''; // Czyszczenie poprzednich opcji
            const defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = 'Wybierz trasę';
            select.appendChild(defaultOption);

            data.forEach(route => {
                const option = document.createElement('option');
                option.value = route.id;
                option.textContent = route.name;
                select.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error fetching routes:', error);
        });
}

// Ładowanie szczegółów wybranej trasy
function fetchRouteDetails() {
    const select = document.getElementById('routeSelect');
    const routeId = select.value;

    console.log('Selected route ID:', routeId);

    if (!routeId) {
        alert('Proszę wybrać trasę!');
        return;
    }

    fetch(`http://127.0.0.1:3000/routes/${routeId}`)
        .then(response => response.json())
        .then(data => {
            console.log('Route details:', data);
            saveRouteLocally(data); // Zapisanie trasy na urządzeniu
            displayRouteOnMap(data); // Wyświetlanie trasy na mapie
        })
        .catch(error => console.error('Error fetching route details:', error));
}

// Zapisanie trasy na urządzeniu
function saveRouteLocally(route) {
    // Sprawdzamy, czy waypoints są już tablicą obiektów
    if (typeof route.waypoints === 'string') {
        // Jeśli są zapisane jako string, musimy je przekształcić
        route.waypoints = JSON.parse(route.waypoints);
    }

    // Zapisujemy trasę do localStorage
    localStorage.setItem('route', JSON.stringify({
        id: route.id,
        name: route.name,
        waypoints: route.waypoints // Zapewniamy, że jest to tablica obiektów
    }));

    console.log('Route saved in localStorage');
}

// Ładowanie trasy z localStorage
function loadRouteFromLocalStorage() {
    const savedRoute = localStorage.getItem('route');
    if (savedRoute) {
        const route = JSON.parse(savedRoute);
        console.log('Loaded route from localStorage:', route);
        displayRouteOnMap(route); // Wyświetlanie trasy na mapie
    } else {
        console.log('No route found in localStorage');
    }
}

// Wyświetlanie trasy na mapie
function displayRouteOnMap(route) {
    // Usuwamy poprzednie markery i trasę, jeśli istnieją
    if (routeControl) {
        routeControl.remove(); // Usuwamy poprzednią trasę
    }

    routeMarkers.forEach(marker => {
        marker.remove(); // Usuwamy stare markery
    });
    routeMarkers = []; // Resetujemy tablicę markerów

    // Inicjalizujemy nową trasę na mapie
    routeControl = L.Routing.control({
        waypoints: route.waypoints.map(waypoint => L.latLng(waypoint.lat, waypoint.lng)),
        routeWhileDragging: true
    }).addTo(map);

    // Dodajemy markery na trasie
    routeWaypoints = route.waypoints.map(waypoint => L.latLng(waypoint.lat, waypoint.lng));
    route.waypoints.forEach(waypoint => {
        const marker = L.marker([waypoint.lat, waypoint.lng]).addTo(map)
            .bindPopup(waypoint.description)
            .openPopup();
        routeMarkers.push(marker); // Przechowujemy marker w tablicy
    });

    // Resetowanie indeksu trasy
    currentWaypointIndex = 0;

    // Dodanie poruszającego się markera na początku trasy
    if (!movingMarker) {
        movingMarker = L.circleMarker(routeWaypoints[currentWaypointIndex], {
            radius: 8,
            color: 'blue',
            fillColor: 'blue',
            fillOpacity: 0.6
        }).addTo(map);
    } else {
        movingMarker.setLatLng(routeWaypoints[currentWaypointIndex]);
    }

    map.panTo(routeWaypoints[currentWaypointIndex]);
}

// Funkcja nawigacji do bieżącej lokalizacji użytkownika
function navigateToCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            const userLocation = L.latLng(lat, lng);

            // Dodajemy marker dla użytkownika
            L.marker(userLocation).addTo(map)
                .bindPopup('Twoja lokalizacja')
                .openPopup();

            // Ustawiamy widok mapy na lokalizację użytkownika
            map.setView(userLocation, 13);
        }, () => {
            alert('Nie udało się pobrać lokalizacji.');
        });
    } else {
        alert('Geolokalizacja nie jest obsługiwana przez Twoją przeglądarkę.');
    }
}

// Przemieszczanie do następnego punktu trasy
function moveToNextWaypoint() {
    if (routeWaypoints.length === 0) {
        alert('Proszę wybrać trasę!');
        return;
    }

    if (currentWaypointIndex < routeWaypoints.length - 1) {
        currentWaypointIndex++;
    } else {
        currentWaypointIndex = 0; // Zresetuj do początku trasy, jeśli osiągniesz koniec
    }

    const waypoint = routeWaypoints[currentWaypointIndex];
    moveMarkerToWaypoint(waypoint);
}

// Przemieszczanie markera na nowy punkt trasy
function moveMarkerToWaypoint(waypoint) {
    if (!movingMarker) {
        movingMarker = L.circleMarker(waypoint, {
            radius: 8,
            color: 'blue',
            fillColor: 'blue',
            fillOpacity: 0.6
        }).addTo(map);
    } else {
        movingMarker.setLatLng(waypoint);
    }

    map.panTo(waypoint);
}
