let map; // Tworzymy zmienną globalną do przechowywania mapy
let db;  // Zmienna do przechowywania instancji bazy danych SQLite

document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
  // Inicjalizacja bazy danych SQLite
  db = window.sqlitePlugin.openDatabase({ name: 'routes.db', location: 'default' });

  // Tworzenie tabeli, jeśli jeszcze nie istnieje
  db.transaction(function(tx) {
    tx.executeSql('CREATE TABLE IF NOT EXISTS routes (id INTEGER PRIMARY KEY, name TEXT, waypoints TEXT)');
  });

  // Inicjalizacja mapy
  map = L.map('map').setView([51.505, -0.09], 13);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
  }).addTo(map);

  fetchRoutes(); // Ładowanie tras po załadowaniu aplikacji
}

function fetchRoutes() {
  console.log('Fetching routes...');
  fetch('http://127.0.0.1:3000/routes')  // Zmiana localhost na 127.0.0.1
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      console.log('Received data:', data);
      const select = document.getElementById('routeSelect');
      select.innerHTML = ''; // Czyszczenie poprzednich opcji
      const defaultOption = document.createElement('option');
      defaultOption.value = '';
      defaultOption.textContent = 'Wybierz trasę';
      select.appendChild(defaultOption);

      data.forEach(route => {
        const option = document.createElement('option');
        option.value = route.id;
        option.textContent = route.name;
        select.appendChild(option);
      });
    })
    .catch(error => {
      console.error('Error fetching routes:', error);
    });
}

function fetchRouteDetails() {
  const select = document.getElementById('routeSelect');
  const routeId = select.value;

  console.log('Selected route ID:', routeId);

  if (!routeId) {
    alert('Proszę wybrać trasę!');
    return;
  }

  // Sprawdzenie, czy trasa jest już zapisana lokalnie
  loadRouteFromDatabase(routeId); // Zamiast fetcha, próbujemy załadować trasę z bazy danych

  fetch(`http://localhost:3000/routes/${routeId}`)
    .then(response => response.json())
    .then(data => {
      console.log('Route details:', data);
      saveRouteLocally(data); // Zapisanie trasy na urządzeniu
      displayRouteOnMap(data); // Wyświetlanie trasy na mapie
    })
    .catch(error => console.error('Error fetching route details:', error));
}

function saveRouteLocally(route) {
  const waypoints = JSON.stringify(route.waypoints); // Serializujemy waypointy do JSON

  db.transaction(function(tx) {
    tx.executeSql('INSERT INTO routes (id, name, waypoints) VALUES (?, ?, ?)', [route.id, route.name, waypoints], function(tx, result) {
      console.log('Route saved to database');
    }, function(error) {
      console.error('Error saving route to database', error);
    });
  });
}

function loadRouteFromDatabase(routeId) {
  db.transaction(function(tx) {
    tx.executeSql('SELECT * FROM routes WHERE id = ?', [routeId], function(tx, result) {
      if (result.rows.length > 0) {
        const route = result.rows.item(0);
        console.log('Loaded route from database:', route);
        const routeData = {
          id: route.id,
          name: route.name,
          waypoints: JSON.parse(route.waypoints) // Deserializujemy waypointy z JSON
        };
        displayRouteOnMap(routeData); // Wyświetlanie trasy na mapie
      } else {
        console.log('Route not found in database');
      }
    }, function(error) {
      console.error('Error loading route from database', error);
    });
  });
}

function displayRouteOnMap(route) {
  // Teraz tylko dodajemy markery do już istniejącej mapy
  route.waypoints.forEach(waypoint => {
    L.marker([waypoint.lat, waypoint.lng]).addTo(map)  // 'map' to już istniejąca zmienna
      .bindPopup(waypoint.description)
      .openPopup();
  });
}
